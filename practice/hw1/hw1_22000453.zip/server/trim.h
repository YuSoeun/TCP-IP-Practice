#ifndef __TRIM_H__
#define __TRIM_H__

char* trim_left(char* str);
char* trim_right(char* str);
char *trim(char *str);

#endif